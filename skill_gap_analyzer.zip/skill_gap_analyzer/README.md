# Skill Gap Analyzer

## Problem Statement
Candidates often know some skills required for a job but may be missing other skills
or have them at a lower proficiency level. The project provides a structured report
showing exactly which skills need improvement.

## Objective
Build a zero-cost Python application that compares a candidate's skill levels with
role requirements, calculates a weighted match score, identifies gaps, and creates
a prioritized learning plan.

## Features
- Candidate skills stored in JSON
- Job-role requirements stored in JSON
- Beginner / Intermediate / Advanced levels
- Matched and missing skill detection
- Detects skills present at a lower level than required
- Weighted skill match percentage
- Priority-based action plan
- JSON and CSV persistence
- Validation and exception handling
- Automated unit tests

## Technologies Used
- Python 3.10+
- Standard-library modules: json, csv, pathlib, unittest
- No paid APIs or external packages

## Installation / Setup
1. Install Python 3.10 or later.
2. Extract/open this project.
3. No external packages are required.

## How to Run
```bash
python app.py
```
Press Enter at both prompts to use the included sample JSON files.

## Project Structure
```text
skill_gap_analyzer/
├── app.py
├── analyzer.py
├── report_manager.py
├── data/
│   ├── candidate.json
│   └── roles/
│       └── software_engineer.json
├── reports/
├── tests/
│   └── test_analyzer.py
├── README.md
└── PROJECT_REPORT.md
```

## Testing Details
Run:
```bash
python -m unittest discover -s tests -v
```
The tests cover matched skills, lower proficiency, missing skills, invalid levels,
invalid priorities, and duplicate requirements.

## Limitations
- Skill names must be entered consistently; synonym handling is not automatic.
- Proficiency is based on the three defined levels.
- The current interface is command-line based.

## Future Improvements
- Import skills directly from resumes.
- Add a learning-resource recommendation module.
- Add charts and a web dashboard.
- Add semantic skill matching and synonyms.
- Store multiple candidates and roles in a database.
