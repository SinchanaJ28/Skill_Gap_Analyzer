from analyzer import SkillGapAnalyzer
from report_manager import ReportManager

def print_profile(profile):
    print("\nCandidate Profile")
    print("-" * 40)
    for skill, level in sorted(profile.items()):
        print(f"{skill:<20} {level}")

def main():
    print("\n=== Skill Gap Analyzer ===")
    candidate_path = input("Candidate JSON [data/candidate.json]: ").strip() or "data/candidate.json"
    role_path = input("Role JSON [data/roles/software_engineer.json]: ").strip() or "data/roles/software_engineer.json"

    try:
        analyzer = SkillGapAnalyzer()
        result = analyzer.analyze_files(candidate_path, role_path)

        print(f"\nRole: {result['role']}")
        print_profile(result["candidate_skills"])

        print("\n--- Skill Gap Report ---")
        print(f"Match score: {result['match_percentage']:.2f}%")
        print(f"Matched skills: {', '.join(result['matched_skills']) or 'None'}")
        print(f"Missing skills: {', '.join(result['missing_skills']) or 'None'}")

        print("\nPriority action plan:")
        for item in result["priority_plan"]:
            print(
                f"  {item['skill']}: required={item['required_level']}, "
                f"candidate={item['candidate_level']}, priority={item['priority']}"
            )

        ReportManager.save_json(result, "reports/skill_gap_report.json")
        ReportManager.save_csv(result, "reports/skill_gap_report.csv")
        print("\nReports saved to reports/skill_gap_report.json and reports/skill_gap_report.csv")

    except FileNotFoundError as exc:
        print(f"File error: {exc}")
    except ValueError as exc:
        print(f"Input error: {exc}")
    except Exception as exc:
        print(f"Unexpected error: {exc}")

if __name__ == "__main__":
    main()
