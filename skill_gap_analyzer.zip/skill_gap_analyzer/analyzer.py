import json
from pathlib import Path

class SkillGapAnalyzer:
    LEVELS = {"Beginner": 1, "Intermediate": 2, "Advanced": 3}

    def __init__(self):
        self.role = None

    @staticmethod
    def _load_json(path):
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"JSON file not found: {path}")
        if path.suffix.lower() != ".json":
            raise ValueError("Input must be a JSON file.")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path}: {exc.msg}") from exc

    def _validate_candidate(self, data):
        if not isinstance(data, dict):
            raise ValueError("Candidate data must be a JSON object.")
        skills = data.get("skills")
        if not isinstance(skills, dict) or not skills:
            raise ValueError("Candidate JSON must contain a non-empty 'skills' object.")
        cleaned = {}
        for skill, level in skills.items():
            if not isinstance(skill, str) or not skill.strip():
                raise ValueError("Candidate skill names must be non-empty strings.")
            level = str(level).title()
            if level not in self.LEVELS:
                raise ValueError(f"Invalid candidate level for {skill}: {level}")
            cleaned[skill.strip()] = level
        return cleaned

    def _validate_role(self, data):
        if not isinstance(data, dict):
            raise ValueError("Role data must be a JSON object.")
        role = data.get("role")
        requirements = data.get("requirements")
        if not isinstance(role, str) or not role.strip():
            raise ValueError("Role name is required.")
        if not isinstance(requirements, list) or not requirements:
            raise ValueError("Role must contain a non-empty requirements list.")

        cleaned = []
        seen = set()
        for item in requirements:
            if not isinstance(item, dict):
                raise ValueError("Each requirement must be an object.")
            skill = str(item.get("skill", "")).strip()
            level = str(item.get("level", "")).title()
            priority = str(item.get("priority", "Medium")).title()
            if not skill:
                raise ValueError("Every requirement needs a skill name.")
            if level not in self.LEVELS:
                raise ValueError(f"Invalid required level for {skill}: {level}")
            if priority not in {"High", "Medium", "Low"}:
                raise ValueError(f"Invalid priority for {skill}: {priority}")
            key = skill.lower()
            if key not in seen:
                cleaned.append({"skill": skill, "level": level, "priority": priority})
                seen.add(key)

        return role.strip(), cleaned

    def analyze(self, candidate_data, role_data):
        candidate = self._validate_candidate(candidate_data)
        role, requirements = self._validate_role(role_data)
        self.role = role

        candidate_lookup = {k.lower(): (k, v) for k, v in candidate.items()}
        matched, missing, plan = [], [], []

        priority_order = {"High": 1, "Medium": 2, "Low": 3}
        total_required = len(requirements)
        achieved_points = 0
        total_points = sum(self.LEVELS[item["level"]] for item in requirements)

        for req in requirements:
            key = req["skill"].lower()
            if key in candidate_lookup:
                original_name, candidate_level = candidate_lookup[key]
                achieved = min(self.LEVELS[candidate_level], self.LEVELS[req["level"]])
                achieved_points += achieved

                if self.LEVELS[candidate_level] >= self.LEVELS[req["level"]]:
                    matched.append(req["skill"])
                else:
                    missing.append(req["skill"])
                    plan.append({
                        "skill": req["skill"],
                        "required_level": req["level"],
                        "candidate_level": candidate_level,
                        "priority": req["priority"]
                    })
            else:
                missing.append(req["skill"])
                plan.append({
                    "skill": req["skill"],
                    "required_level": req["level"],
                    "candidate_level": "Not Available",
                    "priority": req["priority"]
                })

        plan.sort(key=lambda x: (priority_order[x["priority"]], -self.LEVELS[x["required_level"]], x["skill"].lower()))
        match_percentage = (achieved_points / total_points * 100) if total_points else 0.0

        return {
            "role": role,
            "candidate_skills": candidate,
            "required_skills": requirements,
            "matched_skills": sorted(matched, key=str.lower),
            "missing_skills": sorted(set(missing), key=str.lower),
            "match_percentage": match_percentage,
            "priority_plan": plan,
            "total_required_skills": total_required
        }

    def analyze_files(self, candidate_path, role_path):
        return self.analyze(self._load_json(candidate_path), self._load_json(role_path))
