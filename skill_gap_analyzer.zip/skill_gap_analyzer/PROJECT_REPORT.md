# Project Report — Skill Gap Analyzer

## 1. Problem Understanding
A candidate may satisfy a job requirement partially, fully, or not at all. A simple
keyword match cannot distinguish between "Beginner" and "Advanced". This project
therefore compares proficiency levels as well as skill presence.

## 2. Proposed Approach
Candidate skills and job requirements are represented as JSON data. Each skill has
a proficiency level. The analyzer converts levels into numeric values, compares
candidate and required levels, calculates a weighted score, identifies gaps, and
sorts the gaps into a practical action plan.

## 3. Implementation
- `app.py`: user interaction and exception handling.
- `analyzer.py`: validation, level comparison, scoring and prioritization.
- `report_manager.py`: JSON and CSV report persistence.
- `data/candidate.json`: sample candidate profile.
- `data/roles/software_engineer.json`: sample role.
- `tests/test_analyzer.py`: automated tests.

## 4. Important Technical Decisions
Three proficiency levels were used to keep the system understandable and explainable.
A weighted score is more informative than simply counting matching skill names because
an Advanced requirement deserves more weight than a Beginner requirement. JSON was
selected for persistence because it is free, readable and easy to modify.

## 5. Testing Performed
Six tests cover matched skills, lower proficiency, missing skills, invalid candidate
levels, invalid priorities and duplicate role requirements.

## 6. Challenges and Solutions
The main challenge was deciding how to score partial proficiency. The application
converts Beginner, Intermediate and Advanced into 1, 2 and 3, then awards achieved
points up to the required level. This makes the result transparent and easy to explain.

## 7. Future Scope
The system can be connected to the Resume Keyword Analyzer, automatically extract
candidate skills, recommend learning resources, support many roles, and provide a
web dashboard.
