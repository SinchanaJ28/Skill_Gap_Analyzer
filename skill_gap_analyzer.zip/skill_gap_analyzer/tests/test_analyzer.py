import unittest
from analyzer import SkillGapAnalyzer

class TestSkillGapAnalyzer(unittest.TestCase):
    def setUp(self):
        self.analyzer = SkillGapAnalyzer()
        self.candidate = {
            "skills": {
                "Python": "Advanced",
                "SQL": "Intermediate",
                "Git": "Intermediate"
            }
        }
        self.role = {
            "role": "Backend Developer",
            "requirements": [
                {"skill": "Python", "level": "Intermediate", "priority": "High"},
                {"skill": "SQL", "level": "Advanced", "priority": "High"},
                {"skill": "Docker", "level": "Intermediate", "priority": "Medium"}
            ]
        }

    def test_matched_skill(self):
        result = self.analyzer.analyze(self.candidate, self.role)
        self.assertIn("Python", result["matched_skills"])

    def test_lower_level_creates_gap(self):
        result = self.analyzer.analyze(self.candidate, self.role)
        self.assertIn("SQL", result["missing_skills"])

    def test_missing_skill_creates_gap(self):
        result = self.analyzer.analyze(self.candidate, self.role)
        self.assertIn("Docker", result["missing_skills"])

    def test_invalid_candidate_level(self):
        bad = {"skills": {"Python": "Expert"}}
        with self.assertRaises(ValueError):
            self.analyzer.analyze(bad, self.role)

    def test_invalid_role_priority(self):
        bad_role = {
            "role": "Developer",
            "requirements": [
                {"skill": "Python", "level": "Intermediate", "priority": "Critical"}
            ]
        }
        with self.assertRaises(ValueError):
            self.analyzer.analyze(self.candidate, bad_role)

    def test_duplicate_requirements_are_removed(self):
        duplicate_role = {
            "role": "Developer",
            "requirements": [
                {"skill": "Python", "level": "Intermediate", "priority": "High"},
                {"skill": "Python", "level": "Intermediate", "priority": "High"}
            ]
        }
        result = self.analyzer.analyze(self.candidate, duplicate_role)
        self.assertEqual(len(result["required_skills"]), 1)

if __name__ == "__main__":
    unittest.main()
