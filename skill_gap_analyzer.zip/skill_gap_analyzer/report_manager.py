import csv
import json
from pathlib import Path

class ReportManager:
    @staticmethod
    def save_json(result, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(result, indent=4), encoding="utf-8")

    @staticmethod
    def save_csv(result, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Skill", "Required Level", "Candidate Level", "Priority", "Status"])
            candidate = {k.lower(): v for k, v in result["candidate_skills"].items()}
            for req in result["required_skills"]:
                level = candidate.get(req["skill"].lower(), "Not Available")
                status = "Matched" if req["skill"] in result["matched_skills"] else "Gap"
                writer.writerow([req["skill"], req["level"], level, req["priority"], status])
